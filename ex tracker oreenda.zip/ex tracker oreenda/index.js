const express = require('express');
const app = express();
const cors = require('cors');
require('dotenv').config();

const mongoose = require('mongoose');
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));
const userSchema = new mongoose.Schema({
  username: {
    type: String,
    unique: true,
  },
}, { versionKey: false });

const User = mongoose.model('User', userSchema);
const exerciseSchema = new mongoose.Schema({
  username: String,
  description: String,
  duration: Number,
  date: Date,
  userId: String
}, { versionKey: false });
const Exercise = mongoose.model('Exercise', exerciseSchema);

app.use(cors());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// GET request to retrieve all users
app.get('/api/users', async (req, res) => {
  const users = await User.find();
  res.send(users);
});

// POST request to add a new user
app.post('/api/users', async (req, res) => {
  const { username } = req.body;
  const foundUser = await User.findOne({ username });
  if (foundUser) {
    res.json(foundUser);
  } else {
    const user = await User.create({ username });
    res.json(user);
  }
});

// GET request to retrieve exercise log of a user
app.get('/api/users/:_id/logs', async (req, res) => {
  let { from, to, limit } = req.query;
  const userId = req.params._id;
  const foundUser = await User.findById(userId);
  if (!foundUser) {
    return res.json({ error: 'User not found' });
  }
  let filter = { userId };
  let dateFilter = {};
  if (from) {
    dateFilter["$gte"] = new Date(from);
  }
  if (to) {
    dateFilter['$lte'] = new Date(to);
  }
  if (from || to) { 
    filter.date = dateFilter; 
  }
  if (!limit) {
    limit = 100;
  }
  const exercises = await Exercise.find(filter).limit(parseInt(limit));
  const exerciseLog = exercises.map((exercise) => {
    return {
      description: exercise.description,
      duration: exercise.duration,
      date: exercise.date.toDateString(),
    };
  });
  res.json({
    username: foundUser.username,
    count: exercises.length,
    _id: foundUser._id,
    log: exerciseLog,
  });
});

// POST request to add a new exercise to a user's log
app.post('/api/users/:_id/exercises', async (req, res) => {
  const { description, duration, date } = req.body;
  const userId = req.params._id;
  const foundUser = await User.findById(userId);
  if (!foundUser) {
    return res.json({ error: 'User not found' });
  }
  const exercise = await Exercise.create({
    username: foundUser.username,
    description,
    duration,
    date: date ? new Date(date) : new Date(),
    userId,
  });
  res.json({
    username: foundUser.username,
    description: exercise.description,
    duration: exercise.duration,
    date: exercise.date.toDateString(),
    _id: userId,
  });
});



app.get('/', (req, res) => {
  res.sendFile(__dirname + '/views/index.html')
});



const listener = app.listen(process.env.PORT || 3000, () => {
  console.log('Your app is listening on port ' + listener.address().port)
})